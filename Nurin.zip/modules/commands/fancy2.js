const cookie = "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";

module.exports.config = {
    name: "m2t",
    version: "0.0.6",
    hasPermssion: 0,
    credits: "SI TANVIR 6X",
    description: "6X BRAD2 ",
    commandCategory: "6X_FIRE",
    usages: "replay your media ❤️‍🩹",
    cooldowns: 5,
    dependencies: {
  "axios": "",}
};

module.exports.run = async ({ api, event,  args, Currencies}) => {
const axios = require("axios")
    const request = require("request")
    const fs = require("fs-extra")
  const { threadID, messageID, senderID, body } = event;

  var url = event.messageReply.attachments[0].url || args.join(" ")
      if(!url) return api.sendMessage(`Please replay any attachment 🥰🖤`, event.threadID, event.messageID);
  const ser = await axios.get(`https://upload.xanxunder11.repl.co/dir?url=${encodeURIComponent(url)}`);
  var text = ser.data.url_AP;

    // User balance control
    var data = await Currencies.getData(senderID);
    var money = data.money;
var bltxt = "<!--===============[ ENGLISH ]===============-->\n\nYour account does not have enough balance 💔\n\nTo recharge the account balance, message the admin 🖤\n\n📌 Admin ID => \n[ m.me/T4NV1R.BR4ND.Y0UR.N3X7.D4D ]\n\n📞Admin WhatsApp =  > [ wa.me/+8801760226034 ]\n\n<!--===============[ BANGLA ]===============-->\n\nআপনার একাউন্ট এ পর্যাপ্ত পরিমাণ ব্যালেন্স নাই 💔\n\nএকাউন্ট এ ব্যালেন্স রিচার্জ করতে এডমিন কে মেসেজ করুন!\n\n📌 এডমিন আইডি=>\n[ m.me/T4NV1R.BR4ND.Y0UR.N3X7.D4D ]\n\n📞 এডমিন হোয়াটসঅ্যাপ=>\n[ wa.me/+8801760226034 ]";
    if (money < 5) {
        return api.sendMessage(`${bltxt}`, threadID, messageID);
    }

    // Deduct 5 from the user's balance
    Currencies.setData(senderID, { money: money - 5 });

    // Additional functionality (replace this with your specific logic)
    api.sendMessage("Successfully deducted BDT 5 from your balance.", threadID, messageID);

  const ser1 = await axios.get(`https://brand2.xanxunder11.repl.co/v2t?m2turl=${text}&apiKey=${cookie}`);
  var text1 = ser1.data.result_AP;
    return api.sendMessage({body: text1,
attachment: fs.createReadStream(__dirname + `/cache/fuckx/okay/nurin.jpeg`)
}, event.threadID);
                   }
