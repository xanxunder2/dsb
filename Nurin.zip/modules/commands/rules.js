module.exports.config = {
    name: "rules",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "SI TANVIR 6X",
    description: "important notes",
    commandCategory: "random-img",
    usages: "send message",
    cooldowns: 5,
    dependencies: {
        "request": "",
        "fs-extra": "",
        "axios": ""
    }
};

module.exports.run = async({ api, event, args, client, Users, Threads, __GLOBAL, Currencies }) => {
    const axios = global.nodemodule["axios"];
    const request = global.nodemodule["request"];
    const fs = global.nodemodule["fs-extra"];
  const { threadID } = event;
let { threadName, participantIDs } = await api.getThreadInfo(threadID);
var leiamnash3 = (`❐-আসসালামু আলাইকুম,🖤🌺\n\n❐- Group এর কিছু রুলস আছে, এগুলো হয়তো অনেকেই জানেন না যারা জানে না তারা জেনে রাখেন⬅️\n<-------------------------------------------------------------------------->\n\n১) কোন প্রকার বাঝে কথা বলা যাবে না !⚠️\n\n২) বট সেল করা বা বট কিনা এই ধরনের কথা বলা যাবে না ! ⚠️\n\n৩) কোন পর্ণ স্ক্রিনশট কিংবা লিংক দেওয়া  যাবে না !⚠️\n\n৪) কাউকে অপমানিত করে গালি দেওয়া যাবে না !⚠️\n\n৫) বট এর ফাইল চাওয়া যাবে না 🌚🥱 !⚠️\n\n৬)বট নিয়ে কোনো স্ক্রিনশট অথবা ভিডিও দেওয়া যাবে নাহ 🫡\n\n৭) group এ কল করা যাবে না!⚠️\n\n৮) spam করা যাবে না! ⚠️\n\n৯) বট নিয়ে কোন প্রকার টেক্সট করা যাবে না.. আর /help ফাইলে এ যেই গুলা  আসে এইগুলা শুধু ব্যাবাহর করবেন 🙂!\n\n ১০)কোন বট এড করা যাবে না.. বট নিয়ে কোন প্রকার সস ( screen short) দেওয়া বা চাওয়া যাবে না 🙃!⚠️\n\n১১)  গ্রুপে আড্ডা দেওয়া যাবে.. কিন্তু কোন প্রকার লিংক শেয়ার করা যাবে না.. কেবল মাএ facebook /tiktok/Instagram /youtube/ এই গুলা লিংক দেওয়া যাবে ★
কোন  browser এর লিংক বা সস দেওয়া যাবে না! ⚠️\n\n১২) গ্রুপ এ কোনো প্রকার টিউটরিয়াল ভিডিও এর স্ক্রিনশট বা লিংক দেওয়া যাবে নাহ 👈\n\n১৩)আর  গ্রুপে কোন কিছু ইনফরমেশন পরিবর্তন করা যাবে না ..without permission! ⚠️\n<-------------------------------------------------------------------------->\n
  　　　　　　　　　　⤵️🌺\nযারা এই রুলস  গুলে মেনে চলতে পারবেন তারা group থাকেন 🌺আর যারা মানতে পারবেন না লিফট নিবেন, আর রুলস না মানলে সম্মান এর সাথে ব্যান & কিক দেওয়া হবে\n                                             <-------------------------------------------------------------------------->\n
👉 যারা বট সম্পক  বুঝেন না, তারা এডমিন কে মেনশন দিয়ে বলবেন\n<-------------------------------------------------------------------------->\n              ‌
___সাথেই থাকুন ${threadName}___\n\n　　　　　💖...........ধন্যবাদ সবাইকে...........💖`);
   var leiamnash = [
"https://i.ibb.co/3ScKkzb/Si-tanvir-6x-cp.png",
];
    var leiamnash2 = () => api.sendMessage({ body: leiamnash3, attachment: fs.createReadStream(__dirname + "/cache/LeiamNash1.jpg")}, event.threadID, () => fs.unlinkSync(__dirname + "/cache/LeiamNash1.jpg"), event.messageID);
    return request(encodeURI(leiamnash[Math.floor(Math.random() * leiamnash.length)])).pipe(fs.createWriteStream(__dirname + "/cache/LeiamNash1.jpg")).on("close", () => leiamnash2());
};
